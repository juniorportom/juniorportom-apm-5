 export class User {
 	id: number;
 	name: string;
 	address: string;
 	phone: number; 	
 }