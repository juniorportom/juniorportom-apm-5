export class Product {
    id: number;
    name: string;
    type: string;
    quantity: number;
    price: number;
    url: string;   
}