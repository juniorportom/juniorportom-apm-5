# unipiloto-backend-proyecto-apm-5
Backend o aplicación para los servicios del proyecto productApp

## Instalación

Se utiliza el `package.json` para instalar las dependecias pues es un proyecto que corre sobre `Node.JS` utilizando el framework web `ExpressJS`

``` bash
  $ [sudo] npm install
```


## Ejecución

``` bash
  $ [sudo] node app.js
```
