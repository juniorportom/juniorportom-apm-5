INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (2, 'Nokia C10', 'Móvil', 22, 344000, 4.609620, -74.117202);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (3, 'Nokia C3', 'Móvil', 15, 344000, 4.629468, -74.15771);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (4, 'Motorola Moto G LTE', 'Smartphone', 10, 580782, 4.636654, -74.069480);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (5, 'Lanix S107', 'smartphone Android', 20, 250000, 15, 344000, 4.629468, -74.15771);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (6, 'Casio W333', 'Reloj', 5, 23459, 4.609620, -74.117202);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (7, 'Quanta QDP 4G', 'Mi-Fi UNE 4G LTE', 10, 245678, 4.636654, -74.069480);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (8, 'Keon 106 ', 'Firefox OS Device Smartphone ', 12, 199080, 4.609620, -74.117202);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (9, 'Avvio 720', 'Smartphone', 30, 450234, 4.609620, -74.117202);
INSERT INTO product (id, name, type, quantity, price, latitude, longitude) VALUES (10, 'Motorola Moto G 2da G. ', 'Smartphone', 10, 750852.35, 4.636654, -74.069480);
